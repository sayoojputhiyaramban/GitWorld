<?php
//for more info kingjs.info@gmail.com
?>
		<link href="bootstrap_ac/bootstrap.ac.install.css" rel="stylesheet">
		<link href="bootstrap_ac/bootstrap.ac.css" rel="stylesheet">
		<script src="js.ac/jquery-1.10.2.ac.js"></script>
		<script src="js.ac/bootstrap.ac.js"></script>
		<link rel="shortcut icon" href="goodlACk.gif">
<title>Welcome To DEX Connect | POS System</title>
<div class="page-header" align="center" style="font-size:40px; color:#fff; font-family:Tahoma; height:160px; margin-top:-8px; background-image:url(background-header.jpg)" fixed; no-scroll;>
    <br>Inventory & POS  System | 
	dexAC<br>

</div>
