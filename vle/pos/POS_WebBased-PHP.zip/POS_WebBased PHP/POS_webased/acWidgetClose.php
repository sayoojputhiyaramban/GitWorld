<?php
//for more info fb.com/ijsamp
?><div class="col-sm-3">

					<ul class="nav nav-pills nav-stacked well">
						<li>
							<a href="index.php?getACPage==main">Home</a>
						</li>

					</ul>
				</div><br><br><br><br><br>