<?php
//for more info fb.com/ijsamp
?>
		<link href="bootstrap_ac/bootstrap.ac.install.css" rel="stylesheet">
		<link href="bootstrap_ac/bootstrap.ac.css" rel="stylesheet">
		<script src="js.ac/jquery-1.10.2.ac.js"></script>
		<script src="js.ac/bootstrap.ac.js"></script>
		<link rel="shortcut icon" href="goodlACk.gif">

<img src="background-header.jpg">
    AC Corporation <br>
	(BASIC) POS System
</a>
